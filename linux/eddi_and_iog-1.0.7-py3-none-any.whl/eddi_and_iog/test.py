
from myenergi import MyEnergi

API_KEY="zZ0afZRmaDryeBLK48mZ1iZE"
MYENERGI_EDDI_SN="23684238"

me = MyEnergi(API_KEY)
me.set_eddi_serial_number(MYENERGI_EDDI_SN)

on_heater = me.get_eddi_heater_number()
heater_name = MyEnergi.get_tank_name(on_heater)
on_heater_str = f"{on_heater}" if on_heater is not None else "unavailable"

on_heater_watts = me.get_eddi_selected_heater_watts()
p1_str = f"{on_heater_watts} W" if on_heater_watts is not None else "unavailable"

if on_heater_watts:
    print(f"Heater {on_heater_str}/{heater_name} is ON and it is drawing {p1_str}")
else:
    print(f"Heater {on_heater_str}/{heater_name} is OFF.")


on_heater = me.get_eddi_heater_number()
heater_name = MyEnergi.get_tank_name(on_heater)
on_heater_str = f"{on_heater}" if on_heater is not None else "unavailable"

on_heater_watts = me.get_eddi_selected_heater_watts()
p1_str = f"{on_heater_watts} W" if on_heater_watts is not None else "unavailable"

if on_heater_watts:
    print(f"{heater_name} heater ({on_heater_str}) is ON and it is drawing {p1_str}")
else:
    print(f"{heater_name} heater ({on_heater_str}) is OFF.")


tt = me.get_eddi_top_tank_temp()
bt = me.get_eddi_bottom_tank_temp()
tt_str = f"{tt} °C" if tt is not None else "unavailable"
bt_str = f"{bt} °C" if bt is not None else "unavailable"
print(f"Tank Temp    — TOP: {tt_str}, BOTTOM: {bt_str}")

